﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Copy_from_textBox_to_lable_and_clear
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            label3.Text = textBox1.Text;
            label4.Text = textBox2.Text;
            label5.Text = textBox3.Text;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            foreach(Control c in Controls)
            {
                if (c is TextBox)
                {
                    c.Text = " ";
                }
             }
        }

        private void btnClearLbl_Click(object sender, EventArgs e)
        {
            foreach (Control c in Controls)
            {
                if (c is Label)
                {
                    c.Text = " ";
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
